﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public class HomeViewModel
    {
        public List<platform> platformList { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string bearerToken { get; set; }
    }
}
