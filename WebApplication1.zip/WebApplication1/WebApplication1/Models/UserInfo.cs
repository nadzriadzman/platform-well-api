﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public static class UserInfo
    {
        [Required]
        public static string Username { get; set; }
        [Required]
        public static string Password { get; set; }
        public static string BearerToken { get; set; }
    }
}
