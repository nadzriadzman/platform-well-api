﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Schema;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class LoginController : Controller
    {
        private IConfiguration _config;

        public LoginController(IConfiguration configuration)
        {
            _config = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Login(string username, string password)
        {
            var WebAPIBaseUrl = _config.GetValue<string>("WebAPIBaseUrl");
            using (var httpClient = new HttpClient())
            {

                var LoginCredential = new { username, password };
                var json = JsonConvert.SerializeObject(LoginCredential);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                
                using (var response = await httpClient.PostAsync(WebAPIBaseUrl +"/Account/Login", data))
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        UserInfo.BearerToken = JsonConvert.DeserializeObject<string>(apiResponse);
                        UserInfo.Username = username;
                        UserInfo.Password = password;
                    }
                }
            }
            return RedirectToAction("Index", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
