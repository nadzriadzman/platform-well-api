﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        
        private IConfiguration _config;

        private DatabaseContext _context;
        public string message;
        public string status;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration, DatabaseContext context)
        {
            _logger = logger;
            _config = configuration;
            _context = context;
        }

        public IActionResult Index()
        {
            HomeViewModel model = new HomeViewModel();
            model.platformList = _context.platform.ToList();
            model.email = UserInfo.Username;
            model.password = UserInfo.Password;
            model.bearerToken = UserInfo.BearerToken;
            return View(model);
        }

        public IActionResult PlatformDetails(int id = 0)
        {
            if (id > 0)
            {
                var wellList = _context.well.Where(m => m.platformId == id).ToList();
                if (wellList != null) {
                    ViewData["platformId"] = id;
                    return View(wellList);
                }
                else
                {
                     return View();
                }

            }
            else {
                return View();
            }
        
        }

        [HttpGet]
        public async Task<JsonResult> SyncData()
        {
            var name = UserInfo.Username;
            var pass = UserInfo.Password;
            var bearerToken = UserInfo.BearerToken;
            var WebAPIBaseUrl = _config.GetValue<string>("WebAPIBaseUrl");
            var responseData = new object();
            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Authorization
                         = new AuthenticationHeaderValue("Bearer", bearerToken);

                using (var response = await httpClient.GetAsync(WebAPIBaseUrl + "/PlatformWell/GetPlatformWellActual"))
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        var myJsonObject = JsonConvert.DeserializeObject<List<GetPlatformWellActualAPIViewModel>>(apiResponse);

                        if (myJsonObject.Count() > 0)
                        {
                            foreach (var item in myJsonObject)
                            {
                                var plat = _context.platform.Where(m => m.Id == item.id).FirstOrDefault();
                                if (plat != null)
                                {
                                    /** update platform record **/
                                    plat.uniqueName = item.uniqueName;
                                    plat.latitude = item.latitude;
                                    plat.longitude = item.longitude;
                                    plat.updatedAt = item.updatedAt;
                                    _context.SaveChanges();

                                    if (item.well.Count() > 0)
                                    {
                                        foreach (var data in item.well)
                                        {
                                            var well = _context.well.Where(m => m.Id == data.id).Where(m => m.platformId == plat.Id).FirstOrDefault();
                                            if (well != null)
                                            {
                                                /** update well record **/
                                                well.uniqueName = data.uniqueName;
                                                well.latitude = data.latitude;
                                                well.longitude = data.longitude;
                                                well.updatedAt = data.updatedAt;
                                                _context.SaveChanges();
                                            }
                                            else
                                            {
                                                /** create well recprd **/
                                                well w = new well();
                                                w.Id = data.id;
                                                w.platformId = item.id;
                                                w.uniqueName = data.uniqueName;
                                                w.latitude = data.latitude;
                                                w.longitude = data.longitude;
                                                w.createdAt = data.createdAt;
                                                w.updatedAt = data.updatedAt;
                                                _context.well.Add(w);
                                                _context.SaveChanges();
                                            }
                                        }//end of foreach
                                    }
                                    status = "success";
                                    message = "Data has been successfully updated";
                                }
                                else
                                {
                                    /** create platform record **/
                                    platform p = new platform();
                                    p.Id = item.id;
                                    p.uniqueName = item.uniqueName;
                                    p.latitude = item.latitude;
                                    p.longitude = item.longitude;
                                    p.createdAt = item.createdAt;
                                    p.updatedAt = item.updatedAt;

                                    _context.platform.Add(p);
                                    _context.SaveChanges();
                                    if (item.well.Count() > 0)
                                    {
                                        foreach (var data in item.well)
                                        {
                                            var well = _context.well.Where(m => m.Id == data.id).Where(m => m.platformId == plat.Id).FirstOrDefault();
                                            if (well != null)
                                            {
                                                /** update well record **/
                                                well.uniqueName = data.uniqueName;
                                                well.latitude = data.latitude;
                                                well.longitude = data.longitude;
                                                well.updatedAt = data.updatedAt;
                                                _context.SaveChanges();
                                            }
                                            else
                                            {
                                                /** create well record **/
                                                well w = new well();
                                                w.Id = data.id;
                                                w.platformId = item.id;
                                                w.uniqueName = data.uniqueName;
                                                w.latitude = data.latitude;
                                                w.longitude = data.longitude;
                                                w.createdAt = data.createdAt;
                                                w.updatedAt = data.updatedAt;
                                                _context.well.Add(w);
                                                _context.SaveChanges();
                                            }
                                        }// end of foreach
                                    }
                                    status = "success";
                                    message = "Data has been successfully created";
                                }//end of else

                            }
                        }
                    }
                }
            }

            responseData = new
            {
                status = status,
                message = message
            };
            return Json(responseData);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
