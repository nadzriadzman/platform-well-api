﻿select p.uniqueName, w.Id, w.updatedAt
from dbo.platform as p
inner join dbo.well as w on p.id = w.platformId
where w.updatedAt = (select max(w.updatedAt)
                        from dbo.well as w where w.platformId = p.Id)
ORDER BY P.uniqueName;